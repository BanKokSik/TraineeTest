//
//  DetailImageModel.swift
//  TraineeTest
//
//  Created by Nikita Chekmarev on 27.07.2021.
//

import Foundation

struct DetailImageModel {
    var imageRequest: String?
    var titleLabelText: String?
    var textLabelText: String?
}
